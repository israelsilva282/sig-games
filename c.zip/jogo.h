void telaJogo(void);
void telaAdicionarJogo(void);
void telaPesquisarJogo(void);
void telaListarJogos(void);
void telaEditarJogo(void);
void telaRemoverJogo(void);