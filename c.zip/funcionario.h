void telaFuncionario(void);
void telaAdicionarFuncionario(void);
void telaPesquisarFuncionario(void);
void telaEditarFuncionario(void);
void telaRemoverFuncionario(void);
