
void telaCliente(void);
void telaAdicionarCliente(void);
void telaPesquisarCliente(void);
void telaEditarCliente(void);
void telaRemoverCliente(void);