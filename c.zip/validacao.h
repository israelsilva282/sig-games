int checkBissexto(int);
int checkData(int, int, int);
int checkCPF(char *);
int checkEmail(char *);
int checkNome(char *);
int checkEndereco(char *);
int checkResumo(char *);